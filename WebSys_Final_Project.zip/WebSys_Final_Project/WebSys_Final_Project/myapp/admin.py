from django.contrib import admin
from .models import Applicant
# Register your models here.


admin.site.register(Applicant)